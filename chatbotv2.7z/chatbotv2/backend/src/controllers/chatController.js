const axios = require('axios');
const db = require('../config/database');

const NLP_SERVICE_URL = process.env.NLP_SERVICE_URL || 'http://nlp-service:5000';

exports.handleChat = async (req, res) => {
  try {
    const { message, userId = 'anonymous' } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    await db.execute(
      'INSERT INTO messages (user_id, message, sender, created_at) VALUES (?, ?, ?, NOW())',
      [userId, message, 'user']
    );

    const nlpResponse = await axios.post(`${NLP_SERVICE_URL}/process`, {
      message: message
    }, { timeout: 30000 });

    const botResponse = nlpResponse.data.response;

    await db.execute(
      'INSERT INTO messages (user_id, message, sender, created_at) VALUES (?, ?, ?, NOW())',
      [userId, botResponse, 'bot']
    );

    res.json({
      response: botResponse,
      confidence: nlpResponse.data.confidence,
      intent: nlpResponse.data.intent
    });

  } catch (error) {
    console.error('Chat error:', error);
    res.status(500).json({
      error: 'Failed to process message',
      details: error.message
    });
  }
};

exports.getHistory = async (req, res) => {
  try {
    const { userId } = req.params;
    const limit = parseInt(req.query.limit) || 50;

    const [rows] = await db.execute(
      'SELECT * FROM messages WHERE user_id = ? ORDER BY created_at DESC LIMIT ?',
      [userId, limit]
    );

    res.json({ messages: rows.reverse() });

  } catch (error) {
    console.error('History error:', error);
    res.status(500).json({ error: 'Failed to fetch history' });
  }
};