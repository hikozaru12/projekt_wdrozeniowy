# Fullstack Chatbot Project

Projekt zawiera frontend (React), backend (Node.js/Express), usługę NLP (FastAPI + Hugging Face), MySQL, Docker Compose i GitHub Actions CI.

Szczegóły i instrukcje konfiguracji znajdują się w projekcie. Sprawdź `.env.example` przed uruchomieniem.
