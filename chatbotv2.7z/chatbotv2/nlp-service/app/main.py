from flask import Flask, request, jsonify
from flask_cors import CORS
import logging
from app.nlp_processor import NLPProcessor
from app.huggingface_client import HuggingFaceClient

app = Flask(__name__)
CORS(app)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize NLP components
nlp_processor = NLPProcessor()
hf_client = HuggingFaceClient()

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'healthy', 'service': 'nlp-service'})

@app.route('/process', methods=['POST'])
def process_message():
    try:
        data = request.get_json()
        message = data.get('message', '')
        
        if not message:
            return jsonify({'error': 'Message is required'}), 400
        
        # Process with NLP
        processed = nlp_processor.process(message)
        
        # Get response from Hugging Face
        response = hf_client.generate_response(
            message, 
            context=processed.get('context', '')
        )
        
        return jsonify({
            'response': response['text'],
            'confidence': response['confidence'],
            'intent': processed.get('intent', 'general'),
            'entities': processed.get('entities', []),
            'sentiment': processed.get('sentiment', 'neutral')
        })
        
    except Exception as e:
        logger.error(f"Error processing message: {str(e)}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
