import os
import requests
from typing import Dict, Any
import logging
import re

logger = logging.getLogger(__name__)

class HuggingFaceClient:
    def __init__(self):
        self.api_key = os.getenv('HUGGINGFACE_API_KEY', '')
        self.model = os.getenv('HF_MODEL', 'microsoft/DialoGPT-medium')
        self.api_url = f"https://api-inference.huggingface.co/models/{self.model}"
        self.headers = {"Authorization": f"Bearer {self.api_key}"}
        
        # Fallback responses if API fails
        self.fallback_responses = {
            'greeting': 'Cześć! Jak mogę Ci dzisiaj pomóc?',
            'farewell': 'Do widzenia! Miłego dnia!',
            'question': 'To ciekawe pytanie. Postaram się na nie odpowiedzieć jak najlepiej.',
            'help': 'Oczywiście pomogę! Zadaj mi pytanie, a postaram się na nie odpowiedzieć.',
            'thanks': 'Nie ma za co! Cieszę się, że mogłem pomóc.',
            'general': 'Rozumiem. Czy mogę w czymś jeszcze pomóc?',
            'PIT-11': 'PIT-11 to formularz informacyjny wystawiany przez pracodawcę, zleceniodawcę lub ZUS, który zawiera dane o dochodach i pobranych zaliczkach na podatek dochodowy, stanowiące podstawę rocznego rozliczenia podatku.',
            'urlop': 'Aby zgłosić urlop, przejdź do systemu HR lub skontaktuj się z działem kadr.',
            'WSB': 'Uczelnia działa w Gdańsku, przy al. Grunwaldzkiej 238A, 80-266 Gdańsk. Początki sięgają 1998 roku – to wtedy odbyły się pierwsze zajęcia w ramach tej instytucji, gdy jeszcze nosiła nazwę Wyższa Szkoła Bankowa w Gdańsku. W kwietniu 2023 roku uczelnia zmieniła nazwę na Uniwersytet WSB Merito w Gdańsku. Uczelnia jest niepubliczna (prywatna) i prowadzi studia I stopna, II stopnia, jednolite magisterskie, podyplomowe, MBA'
        }
    
    def generate_response(self, message: str, context: str = '') -> Dict[str, Any]:
        """Generate response using Hugging Face API"""
        
        # If no API key, use fallback
        if not self.api_key:
            return self._get_fallback_response(message)
        
        try:
            payload = {
                "inputs": message,
                "parameters": {
                    "max_length": 100,
                    "temperature": 0.7,
                    "top_p": 0.9
                }
            }
            
            response = requests.post(
                self.api_url,
                headers=self.headers,
                json=payload,
                timeout=10
            )
            
            if response.status_code == 200:
                result = response.json()
                
                if isinstance(result, list) and len(result) > 0:
                    generated_text = result[0].get('generated_text', '')
                    return {
                        'text': generated_text,
                        'confidence': 0.8,
                        'source': 'huggingface'
                    }
            
            # Fallback if API call fails
            logger.warning(f"HF API returned status {response.status_code}")
            return self._get_fallback_response(message)
            
        except Exception as e:
            logger.error(f"Error calling Hugging Face API: {str(e)}")
            return self._get_fallback_response(message)
    
    def _get_fallback_response(self, message: str) -> Dict[str, Any]:
        """Get fallback response based on message"""
        message_lower = message.lower().strip()

        # 🔹 1. Wykrywanie działań matematycznych (np. 2 + 3, 10-5, 6*7)
        math_pattern = r'^\s*(-?\d+(?:\.\d+)?)\s*([\+\-\*/x])\s*(-?\d+(?:\.\d+)?)\s*$'
        match = re.match(math_pattern, message_lower)
        if match:
            num1, operator, num2 = match.groups()
            num1, num2 = float(num1), float(num2)
            try:
                if operator in ['+', 'plus']:
                    result = num1 + num2
                elif operator in ['-', 'minus']:
                    result = num1 - num2
                elif operator in ['*', 'x', 'razy']:
                    result = num1 * num2
                elif operator in ['/', ':', 'podzielić']:
                    result = num1 / num2
                else:
                    result = None

                if result is not None:
                    return {
                        'text': f"Wynik to {result}.",
                        'confidence': 0.9,
                        'source': 'math'
                    }
            except ZeroDivisionError:
                return {
                    'text': "Nie mogę dzielić przez zero 😅",
                    'confidence': 0.9,
                    'source': 'math'
                }

        # 🔹 2. Standardowe odpowiedzi fallback
        if any(word in message_lower for word in ['cześć', 'hej', 'witaj', 'hello']):
            response = self.fallback_responses['greeting']
        elif any(word in message_lower for word in ['papa', 'do widzenia', 'bye']):
            response = self.fallback_responses['farewell']
        elif any(word in message_lower for word in ['dzięki', 'dziękuję', 'thanks']):
            response = self.fallback_responses['thanks']
        elif any(word in message_lower for word in ['wsb', 'Merito', 'Opisz mi WSB Gdańsk']):
            response = self.fallback_responses['WSB']
        elif any(word in message_lower for word in ['pomoc', 'pomoż', 'help']):
            response = self.fallback_responses['help']
        elif any(word in message_lower for word in ['pit-11', 'pit11', 'czym jest pit-11']):
            response = self.fallback_responses['PIT-11']
        elif any(word in message_lower for word in ['urlop', 'wolne', 'wakacje', 'Jak wziąć urlop']):
            response = self.fallback_responses['urlop']
        elif '?' in message:
            response = self.fallback_responses['question']
        else:
            response = self.fallback_responses['general']
        
        return {
            'text': response,
            'confidence': 0.6,
            'source': 'fallback'
        }
