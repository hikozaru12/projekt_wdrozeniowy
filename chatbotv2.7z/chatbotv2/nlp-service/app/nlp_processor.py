import re
import spacy
from typing import Dict, List, Any

class NLPProcessor:
    def __init__(self):
        try:
            self.nlp = spacy.load('pl_core_news_sm')
        except:
            # Fallback if Polish model not available
            self.nlp = spacy.load('en_core_web_sm')
        
        # Define intents with keywords
        self.intents = {
            'greeting': ['cześć', 'hej', 'witaj', 'dzień dobry', 'hello', 'hi'],
            'farewell': ['papa', 'do widzenia', 'żegnaj', 'bye'],
            'question': ['co', 'jak', 'kiedy', 'gdzie', 'dlaczego', 'kto', 'what', 'how', 'when'],
            'help': ['pomoc', 'pomoż', 'help', 'nie rozumiem'],
            'thanks': ['dzięki', 'dziękuję', 'thanks', 'thank you']
        }
    
    def process(self, text: str) -> Dict[str, Any]:
        """Process text and extract intents, entities, sentiment"""
        doc = self.nlp(text.lower())
        
        # Detect intent
        intent = self._detect_intent(text.lower())
        
        # Extract entities
        entities = [
            {'text': ent.text, 'label': ent.label_}
            for ent in doc.ents
        ]
        
        # Simple sentiment analysis
        sentiment = self._analyze_sentiment(text)
        
        return {
            'intent': intent,
            'entities': entities,
            'sentiment': sentiment,
            'tokens': [token.text for token in doc],
            'context': text
        }
    
    def _detect_intent(self, text: str) -> str:
        """Detect user intent from text"""
        text_lower = text.lower()
        
        for intent, keywords in self.intents.items():
            if any(keyword in text_lower for keyword in keywords):
                return intent
        
        # Check for questions
        if '?' in text:
            return 'question'
        
        return 'general'
    
    def _analyze_sentiment(self, text: str) -> str:
        """Simple sentiment analysis"""
        positive_words = ['dobrze', 'super', 'świetnie', 'excellent', 'great', 'good']
        negative_words = ['źle', 'kiepsko', 'bad', 'terrible', 'awful']
        
        text_lower = text.lower()
        
        if any(word in text_lower for word in positive_words):
            return 'positive'
        elif any(word in text_lower for word in negative_words):
            return 'negative'
        
        return 'neutral'
